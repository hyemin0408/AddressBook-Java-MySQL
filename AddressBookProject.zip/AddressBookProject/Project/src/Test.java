import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Test extends JFrame {

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    private JTextField tfName, tfTel, tfCom;

    public Test() {
        setTitle("homework");
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(new JLabel("이름"));
        tfName = new JTextField(10);
        inputPanel.add(tfName);

        inputPanel.add(new JLabel("전화번호"));
        tfTel = new JTextField(13);
        inputPanel.add(tfTel);

        inputPanel.add(new JLabel("회사이름"));
        tfCom = new JTextField(20);
        inputPanel.add(tfCom);

        add(inputPanel, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new GridLayout(3, 2));
        JButton btnInsert = new JButton("입력");
        JButton btnSelect = new JButton("조회");
        JButton btnSearch = new JButton("검색");
        JButton btnUpdate = new JButton("수정");
        JButton btnDelete = new JButton("삭제");
        JButton btnExit = new JButton("종료");

        btnPanel.add(btnInsert);
        btnPanel.add(btnSelect);
        btnPanel.add(btnSearch);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnExit);
        add(btnPanel, BorderLayout.CENTER);

        connectDB();

        btnInsert.addActionListener(e -> insertData());
        btnSelect.addActionListener(e -> selectAll());
        btnSearch.addActionListener(e -> searchData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnExit.addActionListener(e -> System.exit(0));

        setSize(500, 400);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void connectDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/mydb?serverTimezone=UTC",
                    "root", "dongyang"
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void insertData() {
        String sql = "INSERT INTO addrtbl (name, tel, com) VALUES (?, ?, ?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfName.getText());
            pstmt.setString(2, tfTel.getText());
            pstmt.setString(3, tfCom.getText());
            int result = pstmt.executeUpdate();
            if (result > 0) {
                System.out.println("입력 성공!");
                selectAll(); 
            } else {
                System.out.println("입력 실패!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void selectAll() {
        String sql = "SELECT * FROM addrtbl";

        System.out.println();
        System.out.printf("%-3s %-10s %-13s %-15s %-20s\n", "ID", "이름", "전화번호", "회사이름", "등록일자");
        System.out.println("--------------------------------------------------------------------------");

        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.printf("%-3d %-10s %-13s %-15s %-20s\n",
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("tel"),
                        rs.getString("com"),
                        rs.getTimestamp("inDate").toString().substring(0, 19)
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void searchData() {
        String sql = "SELECT * FROM addrtbl WHERE name = ?";

        System.out.println();
        System.out.printf("%-3s %-10s %-13s %-15s %-20s\n", "ID", "이름", "전화번호", "회사이름", "등록일자");
        System.out.println("--------------------------------------------------------------------------");

        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfName.getText());
            rs = pstmt.executeQuery();
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.printf("%-3d %-10s %-13s %-15s %-20s\n",
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("tel"),
                        rs.getString("com"),
                        rs.getTimestamp("inDate").toString().substring(0, 19)
                );
            }
            if (!found) {
                System.out.println("검색 결과가 없습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateData() {
        String sql = "UPDATE addrtbl SET tel = ?, com = ? WHERE name = ?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfTel.getText());
            pstmt.setString(2, tfCom.getText());
            pstmt.setString(3, tfName.getText());
            int result = pstmt.executeUpdate();
            if (result > 0) {
                System.out.println("수정 성공!");
                selectAll();
            } else {
                System.out.println("수정할 데이터가 없습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteData() {
        String sql = "DELETE FROM addrtbl WHERE name = ?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfName.getText());
            int result = pstmt.executeUpdate();
            if (result > 0) {
                System.out.println("삭제 성공!");
                selectAll();
            } else {
                System.out.println("삭제할 데이터가 없습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Test();
    }
}
